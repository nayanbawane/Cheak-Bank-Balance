package com.example.allbankbalance.Card1;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.allbankbalance.Card1.ItemClickListener;
import com.example.allbankbalance.R;

public class Myholder extends RecyclerView.ViewHolder implements View.OnClickListener {

    ImageView img;
    TextView modelText;
    private ItemClickListener itemClickListener;

    public Myholder(@NonNull View itemView){
        super(itemView);
        this.img = itemView.findViewById(R.id.modelImage);
        this.modelText = itemView.findViewById(R.id.modelTitle);;
        itemView.setOnClickListener(this);

    }


    @Override
    public void onClick(View v) {
        this.itemClickListener.onItemClick(v,getLayoutPosition());

    }

    void setItemClickListener(ItemClickListener ic){
        this.itemClickListener = ic;

    }
}

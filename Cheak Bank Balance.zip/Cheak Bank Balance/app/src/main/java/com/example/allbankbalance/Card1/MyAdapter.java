package com.example.allbankbalance.Card1;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.allbankbalance.Card1.Banks.Axis_bank;
import com.example.allbankbalance.Card1.Banks.Bandhan_Bank;
import com.example.allbankbalance.Card1.Banks.Bank_of_mh;
import com.example.allbankbalance.Card1.Banks.BankofBaroda;
import com.example.allbankbalance.Card1.Banks.BankofIndia;
import com.example.allbankbalance.Card1.Banks.Canara_Bank;
import com.example.allbankbalance.Card1.Banks.Central_bank_of_india;
import com.example.allbankbalance.Card1.Banks.Federal_Bank;
import com.example.allbankbalance.Card1.Banks.HDFC_bank;
import com.example.allbankbalance.Card1.Banks.ICICI_bank;
import com.example.allbankbalance.Card1.Banks.Indian_Bank;
import com.example.allbankbalance.Card1.Banks.Indusind_Bank;
import com.example.allbankbalance.Card1.Banks.Karnataka_Bank;
import com.example.allbankbalance.Card1.Banks.Kotak_Bank;
import com.example.allbankbalance.Card1.Banks.PNB_Bank;
import com.example.allbankbalance.Card1.Banks.RBL_Bank;
import com.example.allbankbalance.Card1.Banks.South_India_bank;
import com.example.allbankbalance.Card1.Banks.StateBankofIndia;
import com.example.allbankbalance.Card1.Banks.Union_Bank;
import com.example.allbankbalance.Card1.Banks.Yes_Bank;
import com.example.allbankbalance.R;

import java.util.ArrayList;
import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<Myholder> implements Filterable {

    private Context context;
    private ArrayList<Model> list;
    public ArrayList<Model> modelFullList;

    public MyAdapter(Context context, ArrayList<Model> models) {
        this.context = context;
        this.list = models;
        modelFullList = new ArrayList<>(models);
    }

    @NonNull
    @Override
    public Myholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.model_item,null);
        return new Myholder(view);


    }

    @Override
    public void onBindViewHolder(@NonNull Myholder holder, int position) {

        holder.img.setImageResource(list.get(position).getImage());
        holder.modelText.setText(list.get(position).getTitle());

        holder.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClick(View v, int pos) {
                //Open New Activity
                switch (list.get(pos).getTitle()){
                    case "State Bank of India":{
                        // set intent or open another activity
                        Intent intent = new Intent(context, StateBankofIndia.class);
                        context.startActivity(intent);
                        break;
                    }

                    case "Bank of Baroda":{
                        // set intent or open another activity
                        Intent intent = new Intent(context, BankofBaroda.class);
                        context.startActivity(intent);
                        break;

                    }

                    case "HDFC Bank":{
                        // set intent or open another activity
                        Intent intent = new Intent(context, HDFC_bank.class);
                        context.startActivity(intent);
                        break;

                    }

                    case "Axis Bank":{
                        // set intent or open another activity
                        Intent intent = new Intent(context, Axis_bank.class);
                        context.startActivity(intent);
                        break;
                    }

                    case "ICICI Bank":{
                        // set intent or open another activity
                        Intent intent = new Intent(context, ICICI_bank.class);
                        context.startActivity(intent);
                        break;
                    }

                    case "Bank of India":{
                        // set intent or open another activity
                        Intent intent = new Intent(context, BankofIndia.class);
                        context.startActivity(intent);
                        break;
                    }

                    case "Kotak Mahindra Bank":{
                        // set intent or open another activity
                        Intent intent = new Intent(context, Kotak_Bank.class);
                        context.startActivity(intent);
                        break;
                    }

                    case "Canara Bank":{
                        // set intent or open another activity
                        Intent intent = new Intent(context, Canara_Bank.class);
                        context.startActivity(intent);
                        break;
                    }

                    case "Punjab National Bank":{
                        // set intent or open another activity
                        Intent intent = new Intent(context, PNB_Bank.class);
                        context.startActivity(intent);
                        break;
                    }

                    case "Union Bank":{
                        // set intent or open another activity
                        Intent intent = new Intent(context, Union_Bank.class);
                        context.startActivity(intent);
                        break;
                    }

                    case "Yes Bank":{
                        // set intent or open another activity
                        Intent intent = new Intent(context, Yes_Bank.class);
                        context.startActivity(intent);
                        break;
                    }

                    case "South India Bank":{
                        // set intent or open another activity
                        Intent intent = new Intent(context, South_India_bank.class);
                        context.startActivity(intent);
                        break;
                    }

                    case "Central Bank of India":{
                        // set intent or open another activity
                        Intent intent = new Intent(context, Central_bank_of_india.class);
                        context.startActivity(intent);
                        break;
                    }

                    case "Indian Bank":{
                        // set intent or open another activity
                        Intent intent = new Intent(context, Indian_Bank.class);
                        context.startActivity(intent);
                        break;
                    }

                    case "Karnataka Bank":{
                        // set intent or open another activity
                        Intent intent = new Intent(context, Karnataka_Bank.class);
                        context.startActivity(intent);
                        break;
                    }

                    case "Federal Bank":{
                        // set intent or open another activity
                        Intent intent = new Intent(context, Federal_Bank.class);
                        context.startActivity(intent);
                        break;
                    }


                    case "Bank of Maharashtra":{
                        // set intent or open another activity
                        Intent intent = new Intent(context, Bank_of_mh.class);
                        context.startActivity(intent);
                        break;
                    }

                    case "Indusind Bank":{
                        // set intent or open another activity
                        Intent intent = new Intent(context, Indusind_Bank.class);
                        context.startActivity(intent);
                        break;
                    }

                    case "RBL Bank":{
                        // set intent or open another activity
                        Intent intent = new Intent(context, RBL_Bank.class);
                        context.startActivity(intent);
                        break;
                    }


                    case "Bandhan Bank":{
                        // set intent or open another activity
                        Intent intent = new Intent(context, Bandhan_Bank.class);
                        context.startActivity(intent);
                        break;
                    }
                }
            }
        });


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    @Override
    public Filter getFilter() {
        return itemFilter;
    }

    public Filter itemFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            List<Model> filteredList = new ArrayList<>();
            if (constraint == null || constraint.length() == 0){
                filteredList.addAll(modelFullList);
            }
            else{
                String filterPattern = constraint.toString().toLowerCase().trim();
                for (Model item: modelFullList){
                    if (item.getTitle().toLowerCase().contains(filterPattern)){
                        filteredList.add(item);
                    }
                }
            }
            FilterResults results = new FilterResults();
            results.values = filteredList;
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            list.clear();
            list.addAll((List)results.values);
            notifyDataSetChanged();
        }
    };
}

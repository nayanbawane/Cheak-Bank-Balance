package com.example.allbankbalance.Card1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.MenuItemCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.example.allbankbalance.R;

import java.util.ArrayList;

public class AllBankBalance extends AppCompatActivity {

    private MyAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_bank_balance);


        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 1));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        adapter = new MyAdapter(this, getModels());
        recyclerView.setAdapter(adapter);
    }

    private ArrayList<Model> getModels() {
        ArrayList<Model> models = new ArrayList<>();
        Model p;

        // create item one
        p = new Model();
        p.setTitle("State Bank of India");
        p.setImage(R.drawable.ic_nb_sbi);
        models.add(p);

        p = new Model();
        p.setTitle("Bank of Baroda");
        p.setImage(R.drawable.bank_of_baroda);
        models.add(p);

        p = new Model();
        p.setTitle("HDFC Bank");
        p.setImage(R.drawable.hdfc_bank);
        models.add(p);

        p = new Model();
        p.setTitle("Axis Bank");
        p.setImage(R.drawable.axis_bank);
        models.add(p);

        p = new Model();
        p.setTitle("ICICI Bank");
        p.setImage(R.drawable.icici_bank);
        models.add(p);

        p = new Model();
        p.setTitle("Bank of India");
        p.setImage(R.drawable.bank_of_india);
        models.add(p);

        p = new Model();
        p.setTitle("Kotak Mahindra Bank");
        p.setImage(R.drawable.kotak_bank);
        models.add(p);

        p = new Model();
        p.setTitle("Canara Bank");
        p.setImage(R.drawable.canara_bank);
        models.add(p);

        p = new Model();
        p.setTitle("Punjab National Bank");
        p.setImage(R.drawable.punjab_national_bank);
        models.add(p);

        p = new Model();
        p.setTitle("Union Bank");
        p.setImage(R.drawable.union_bank_of_india);
        models.add(p);

        p = new Model();
        p.setTitle("Yes Bank");
        p.setImage(R.drawable.yes_bank);
        models.add(p);

        p = new Model();
        p.setTitle("South India Bank");
        p.setImage(R.drawable.south_indian_bank);
        models.add(p);

        p = new Model();
        p.setTitle("Central Bank of India");
        p.setImage(R.drawable.central_bank_of_india);
        models.add(p);

        p = new Model();
        p.setTitle("Indian Bank");
        p.setImage(R.drawable.indian_bank);
        models.add(p);

        p = new Model();
        p.setTitle("Karnataka Bank");
        p.setImage(R.drawable.karnataka_bank);
        models.add(p);

        p = new Model();
        p.setTitle("Federal Bank");
        p.setImage(R.drawable.federal_bank);
        models.add(p);

        p = new Model();
        p.setTitle("Bank of Maharashtra");
        p.setImage(R.drawable.bank_of_maharashtra);
        models.add(p);

        p = new Model();
        p.setTitle("Indusind Bank");
        p.setImage(R.drawable.indusind_bank);
        models.add(p);

        p = new Model();
        p.setTitle("RBL Bank");
        p.setImage(R.drawable.rbl_bank);
        models.add(p);

        p = new Model();
        p.setTitle("Bandhan Bank");
        p.setImage(R.drawable.bandhan_bank);
        models.add(p);

        return models;

    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.actionbar,menu);
        MenuItem item = menu.findItem(R.id.search);
        androidx.appcompat.widget.SearchView searchView =
                (androidx.appcompat.widget.SearchView)
                        MenuItemCompat.getActionView(item);

        searchView.setQueryHint("Type Bank Name...");

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener(){
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });
        return true;
    }
}
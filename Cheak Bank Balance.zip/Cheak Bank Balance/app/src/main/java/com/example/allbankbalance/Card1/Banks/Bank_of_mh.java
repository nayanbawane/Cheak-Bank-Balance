package com.example.allbankbalance.Card1.Banks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.allbankbalance.R;

public class Bank_of_mh extends AppCompatActivity {

    public ImageView imageView1, imageView2,imageView3,imageView4,imageView5;
    public TextView textView1,textView2,textView3,textView4,textView5,textView6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bank_of_mh);

        //Image
        imageView1 =(ImageView) findViewById(R.id.yourbankbranch);
        imageView2 =(ImageView) findViewById(R.id.yourbankatm);

        //Image Share
        imageView3 =(ImageView) findViewById(R.id.share_ic1);
        imageView4 =(ImageView) findViewById(R.id.share_ic2);
        imageView5 =(ImageView) findViewById(R.id.share_ic3);

        //TextView
        textView1 = findViewById(R.id.call1);
        textView2 = findViewById(R.id.call2);
        textView3 = findViewById(R.id.call3);


        //Text view Share
        textView4 = findViewById(R.id.share_tx1);
        textView5 = findViewById(R.id.share_tx2);
        textView6 = findViewById(R.id.share_tx3);


        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("geo:0, 0?q=Bank of Maharashtra");
                Intent intent = new Intent(Intent.ACTION_VIEW,uri);
                intent.setPackage("com.google.android.apps.maps");
                startActivity(intent);
            }
        });

        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("geo:0, 0?q=ATM");
                Intent intent = new Intent(Intent.ACTION_VIEW,uri);
                intent.setPackage("com.google.android.apps.maps");
                startActivity(intent);
            }
        });

        // Share intent
        //Balance Inquiry
        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shareintent = new Intent();
                shareintent.setAction(Intent.ACTION_SEND);
                shareintent.putExtra(Intent.EXTRA_TEXT,"Bank of Maharashtra Balance\nInquiry Number is\n09222281818");
                shareintent.setType("text/plain");
                startActivity(Intent.createChooser(shareintent,"Share"));
            }
        });

        //Mini Statement Inquiry
        imageView4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shareintent = new Intent();
                shareintent.setAction(Intent.ACTION_SEND);
                shareintent.putExtra(Intent.EXTRA_TEXT,"Bank of Maharashtra\nMini Statement Inquiry no is \n09223181818\nLATRAN <mpin>\n E.g. LATRAN 1234");
                shareintent.setType("text/plain");
                startActivity(Intent.createChooser(shareintent,"Share"));
            }
        });


        //Coustomer Care No
        imageView5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shareintent = new Intent();
                shareintent.setAction(Intent.ACTION_SEND);
                shareintent.putExtra(Intent.EXTRA_TEXT,"Bank of Maharashtra\nCoustomer Care Number is\n18002334526");
                shareintent.setType("text/plain");
                startActivity(Intent.createChooser(shareintent,"Share"));
            }
        });

        //=====================================================================================================================================
//=====================================================================================================================================


        // Share intent text
        //Balance Inquiry
        textView4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shareintent = new Intent();
                shareintent.setAction(Intent.ACTION_SEND);
                shareintent.putExtra(Intent.EXTRA_TEXT,"Bank of Maharashtra Balance\nInquiry Number is\n09222281818");
                shareintent.setType("text/plain");
                startActivity(Intent.createChooser(shareintent,"Share"));
            }
        });

        //Mini Statement Inquiry
        textView5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shareintent = new Intent();
                shareintent.setAction(Intent.ACTION_SEND);
                shareintent.putExtra(Intent.EXTRA_TEXT,"Bank of Maharashtra\nMini Statement Inquiry no is \n09223181818");
                shareintent.setType("text/plain");
                startActivity(Intent.createChooser(shareintent,"Share"));
            }
        });


        //Coustomer Care No
        textView6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shareintent = new Intent();
                shareintent.setAction(Intent.ACTION_SEND);
                shareintent.putExtra(Intent.EXTRA_TEXT,"Bank of Maharashtra\nCoustomer Care Number is\n18002334526");
                shareintent.setType("text/plain");
                startActivity(Intent.createChooser(shareintent,"Share"));
            }
        });


//=====================================================================================================================================
//=====================================================================================================================================

        // Call intent
        //Balance Inquiry Call
        textView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel: 09222281818"));
                startActivity(intent);
            }
        });


        //Mini Statement Inquiry Call
//        textView2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(Intent.ACTION_DIAL);
//                intent.setData(Uri.parse("tel: 09223181818"));
//                startActivity(intent);
//            }
//        });


        //Coustomer care call
        textView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel: 18002334526"));
                startActivity(intent);
            }
        });


    }
}
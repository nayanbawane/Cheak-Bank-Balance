package com.example.allbankbalance.Card1.Banks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.allbankbalance.R;

public class BankofBaroda extends AppCompatActivity {

    public ImageView imageView1, imageView2,imageView3,imageView4,imageView5;
    public TextView textView1,textView2,textView3,textView4,textView5,textView6;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bankof_baroda);

        //Image
        imageView1 =(ImageView) findViewById(R.id.yourbankbranch);
        imageView2 =(ImageView) findViewById(R.id.yourbankatm);

        //Image Share
        imageView3 =(ImageView) findViewById(R.id.share_ic1);
        imageView4 =(ImageView) findViewById(R.id.share_ic2);
        imageView5 =(ImageView) findViewById(R.id.share_ic3);

        //TextView
        textView1 = findViewById(R.id.call1);
        textView2 = findViewById(R.id.call2);
        textView3 = findViewById(R.id.call3);

        //Text view Share
        textView4 = findViewById(R.id.share_tx1);
        textView5 = findViewById(R.id.share_tx2);
        textView6 = findViewById(R.id.share_tx3);



        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("geo:0, 0?q=Bank of Baroda");
                Intent intent = new Intent(Intent.ACTION_VIEW,uri);
                intent.setPackage("com.google.android.apps.maps");
                startActivity(intent);
            }
        });

        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("geo:0, 0?q=ATM");
                Intent intent = new Intent(Intent.ACTION_VIEW,uri);
                intent.setPackage("com.google.android.apps.maps");
                startActivity(intent);
            }
        });

        // Share intent image
        //Balance Inquiry
        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shareintent = new Intent();
                shareintent.setAction(Intent.ACTION_SEND);
                shareintent.putExtra(Intent.EXTRA_TEXT,"Bank of Baroda\nInquiry Number is\n09223011311");
                shareintent.setType("text/plain");
                startActivity(Intent.createChooser(shareintent,"Share"));
            }
        });

        //Mini Statement Inquiry
        imageView4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shareintent = new Intent();
                shareintent.setAction(Intent.ACTION_SEND);
                shareintent.putExtra(Intent.EXTRA_TEXT,"Bank of Baroda\nMini Statement Inquiry by sms Number is\n5616150");
                shareintent.setType("text/plain");
                startActivity(Intent.createChooser(shareintent,"Share"));
            }
        });


        //Coustomer Care No
        imageView5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shareintent = new Intent();
                shareintent.setAction(Intent.ACTION_SEND);
                shareintent.putExtra(Intent.EXTRA_TEXT,"Bank of Baroda\nCoustomer Care Number is\n180010244455");
                shareintent.setType("text/plain");
                startActivity(Intent.createChooser(shareintent,"Share"));
            }
        });

//=====================================================================================================================================
//=====================================================================================================================================


        // Share intent text
        //Balance Inquiry
        textView4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shareintent = new Intent();
                shareintent.setAction(Intent.ACTION_SEND);
                shareintent.putExtra(Intent.EXTRA_TEXT,"Bank of Baroda\nInquiry Number is\n09223011311");
                shareintent.setType("text/plain");
                startActivity(Intent.createChooser(shareintent,"Share"));
            }
        });

        //Mini Statement Inquiry
        textView5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shareintent = new Intent();
                shareintent.setAction(Intent.ACTION_SEND);
                shareintent.putExtra(Intent.EXTRA_TEXT,"Bank of Baroda\nMini Statement Inquiry by sms Number is\n5616150");
                shareintent.setType("text/plain");
                startActivity(Intent.createChooser(shareintent,"Share"));
            }
        });


        //Coustomer Care No
       textView6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shareintent = new Intent();
                shareintent.setAction(Intent.ACTION_SEND);
                shareintent.putExtra(Intent.EXTRA_TEXT,"Bank of Baroda\nCoustomer Care Number is\n180010244455");
                shareintent.setType("text/plain");
                startActivity(Intent.createChooser(shareintent,"Share"));
            }
        });


//=====================================================================================================================================
//=====================================================================================================================================


        // Call intent
        //Balance Inquiry Call
        textView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel: 09223011"));
                startActivity(intent);
            }
        });


        //Mini Statement Inquiry Call
//        textView2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(Intent.ACTION_DIAL);
//                intent.setData(Uri.parse("tel: "));
//                startActivity(intent);
//            }
//        });


        //Coustomer care call
        textView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel: 180010244455"));
                startActivity(intent);
            }
        });


    }

}
package com.example.allbankbalance.Card1;

import android.view.View;

public interface ItemClickListener {
    void onItemClick(View v, int pos);


}

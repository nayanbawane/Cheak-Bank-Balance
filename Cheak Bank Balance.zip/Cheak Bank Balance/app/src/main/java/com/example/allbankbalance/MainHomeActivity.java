package com.example.allbankbalance;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.allbankbalance.Card1.AllBankBalance;
import com.example.allbankbalance.Card4.EmiCalculator;
import com.example.allbankbalance.NavigationActivity.Developer;
import com.example.allbankbalance.NavigationActivity.Feedback;
import com.example.allbankbalance.NavigationActivity.OtherApps;
import com.example.allbankbalance.NavigationActivity.PrivacyPolicy;
import com.example.allbankbalance.NavigationActivity.RateThisApp;
import com.example.allbankbalance.NavigationActivity.ShareLink;


public class MainHomeActivity extends AppCompatActivity {
    DrawerLayout drawerLayout;
    private long backPressedTime;
    private Toast backToast;
    public ImageView imageView1, imageView2, imageView3, imageView4, imageView5, imageView6;


    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) R.layout.activity_main);
        this.drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        imageView1 =(ImageView) findViewById(R.id.allbankbalance);
        imageView2 =(ImageView) findViewById(R.id.your_nearest_atm);
        imageView3 =(ImageView) findViewById(R.id.your_nearest_bank);
        imageView4 =(ImageView) findViewById(R.id.emicalculator);

        


        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainHomeActivity.this, AllBankBalance.class);
                startActivity(intent);
            }
        });


        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("geo:0, 0?q=ATM");
                Intent intent = new Intent(Intent.ACTION_VIEW,uri);
                intent.setPackage("com.google.android.apps.maps");
                startActivity(intent);
            }
        });

        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("geo:0, 0?q=BANK");
                Intent intent = new Intent(Intent.ACTION_VIEW,uri);
                intent.setPackage("com.google.android.apps.maps");
                startActivity(intent);
            }
        });

        imageView4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainHomeActivity.this, EmiCalculator.class);
                startActivity(intent);
            }
        });


    }

    public void ClickMenu(View view) {
        openDrawer(this.drawerLayout);
    }

    public static void openDrawer(DrawerLayout drawerLayout2) {
        drawerLayout2.openDrawer((int) GravityCompat.START);
    }

    public void ClickLogo(View view) {
        closeDrawer(this.drawerLayout);
    }

    public static void closeDrawer(DrawerLayout drawerLayout2) {
        if (drawerLayout2.isDrawerOpen((int) GravityCompat.START)) {
            drawerLayout2.closeDrawer((int) GravityCompat.START);
        }
    }

    public void ClickHome(View view) {
        closeDrawer(this.drawerLayout);
    }

    public void ClickRateThisApp(View view) {
        redirectActivity(this, RateThisApp.class);
    }


    public void ClickOtherApps(View view) {
        redirectActivity(this, OtherApps.class);
    }

    public void ClickShareLink(View view) {
        Intent shareintent = new Intent();
        shareintent.setAction(Intent.ACTION_SEND);
        shareintent.putExtra(Intent.EXTRA_TEXT,"Hey! Download the Best *Cheak All Bank Balance App*");
        shareintent.setType("text/plain");
        startActivity(Intent.createChooser(shareintent,"Share via"));
    }


    public void ClickFeedback(View view) {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        String UriText = "mailto:" + Uri.encode("nayanbawane00@gmail.com") + "?subject="+
                Uri.encode("Feedback Cheak All Bank Balance App")+ "="+ Uri.encode("");
        Uri uri = Uri.parse(UriText);
        intent.setData(uri);
        startActivity(Intent.createChooser(intent,"send email"));
    }

    public void ClickDeveloper(View view) {
        redirectActivity(this, Developer.class);
    }

    public void ClickPrivacyPolicy(View view) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://bhawaniconsultancyservices.blogspot.com/2021/05/privacy-policy.html"));
        startActivity(browserIntent);
    }


    public void ClickLogout(View view) {
        logout(this);
    }

    public static void logout(final Activity activity) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("Exit");
        builder.setMessage("Are you sure you want to Exit ?");
        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                activity.finishAffinity();
                System.exit(0);
            }
        });
        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.show();
    }

    public static void redirectActivity(Activity activity, Class aClass) {
        Intent intent = new Intent(activity, aClass);
        intent.setFlags(intent.FLAG_ACTIVITY_NEW_TASK);
        activity.startActivity(intent);
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
        closeDrawer(this.drawerLayout);
    }

    @Override
    public void onBackPressed(){




//        if (backPressedTime + 2000 > System.currentTimeMillis()){
//            backToast.cancel();
//            super.onBackPressed();
//            return;
//        }else {
//            backToast = Toast.makeText(getBaseContext(), "Press back again to exit", Toast.LENGTH_SHORT);
//            backToast.show();
//        }
//        backPressedTime = System.currentTimeMillis();
        finishAndRemoveTask();
        this.finishAffinity();

    }
}

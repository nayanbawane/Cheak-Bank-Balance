package com.example.allbankbalance.Card1;

public class Model {
    private String title;
    private int image;

//constructer
    public Model(String title, int image) {
        this.title = title;
        this.image = image;
    }

    public Model() {

    }


    // Getter and Setter


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
